#!/bin/bash
# تثبيت تطبيق "Patient Recovery" على macOS  |  Install "Patient Recovery" on macOS
# الاستخدام: bash install_mac.sh
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
[ -f "$DIR/booking.html" ] || { echo "ERROR: booking.html must be in the same folder as this script."; exit 1; }

TARGET="${1:-/Applications}"
if ! mkdir -p "$TARGET" 2>/dev/null || [ ! -w "$TARGET" ]; then
  TARGET="$HOME/Applications"; mkdir -p "$TARGET"
fi
APP="$TARGET/Patient Recovery.app"

rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$DIR/booking.html" "$APP/Contents/Resources/booking.html"

# الأيقونة: تتحول من icon.png إلى AppIcon.icns باستخدام أدوات ماك الجاهزة
if [ -f "$DIR/icon.png" ] && command -v iconutil >/dev/null 2>&1 && command -v sips >/dev/null 2>&1; then
  SET="$(mktemp -d)/AppIcon.iconset"; mkdir -p "$SET"
  for s in 16 32 128 256 512; do
    sips -z $s $s "$DIR/icon.png" --out "$SET/icon_${s}x${s}.png" >/dev/null
    sips -z $((s*2)) $((s*2)) "$DIR/icon.png" --out "$SET/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns "$SET" -o "$APP/Contents/Resources/AppIcon.icns"
fi

cat > "$APP/Contents/MacOS/PatientRecovery" <<'LAUNCH'
#!/bin/bash
HTML="$(cd "$(dirname "$0")/../Resources" && pwd)/booking.html"
if [ -d "/Applications/Google Chrome.app" ] || [ -d "$HOME/Applications/Google Chrome.app" ]; then
  open -na "Google Chrome" --args --app="file://${HTML// /%20}"   # نافذة مستقلة كأنها تطبيق
else
  open "$HTML"                                            # المتصفح الافتراضي
fi
LAUNCH
chmod +x "$APP/Contents/MacOS/PatientRecovery"

cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Patient Recovery</string>
<key>CFBundleDisplayName</key><string>Patient Recovery</string>
<key>CFBundleIdentifier</key><string>com.patientrecovery.clinic</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundleExecutable</key><string>PatientRecovery</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleVersion</key><string>1.0</string>
<key>CFBundleShortVersionString</key><string>1.0</string>
<key>LSMinimumSystemVersion</key><string>10.13</string>
</dict></plist>
PLIST

touch "$APP"
echo "✔ Installed: $APP"
echo "افتح Launchpad أو مجلد Applications وشغّل Patient Recovery."
open -R "$APP" 2>/dev/null || true
