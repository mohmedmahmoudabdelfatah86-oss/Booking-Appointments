تثبيت "Patient Recovery" على ماك (Mac)
1) فك الضغط عن الملف، وسيب booking.html و icon.png و install_mac.sh في نفس المجلد.
2) افتح Terminal (Cmd + Space ثم اكتب Terminal).
3) اكتب: cd  ثم مسافة، واسحب المجلد داخل Terminal، واضغط Enter.
4) اكتب: bash install_mac.sh   ثم Enter.
5) هتلاقي Patient Recovery في مجلد Applications. اسحبه للـ Dock لو عايز.
الحذف: اسحب Patient Recovery من Applications إلى سلة المحذوفات.
